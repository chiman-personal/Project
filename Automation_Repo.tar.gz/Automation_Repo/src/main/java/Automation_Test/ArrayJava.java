package Automation_Test;

import java.util.Arrays;

public class ArrayJava {
    public static void main(String args[]) {
        String[] strArr = new String[] {"1","2","3"};

        String str = strArr.toString();

        System.out.println(str);
    }
}
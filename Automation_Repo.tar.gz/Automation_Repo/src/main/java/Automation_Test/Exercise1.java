package Automation_Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exercise1 {

    public static void main(String[] args) {
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://letskodeit.teachable.com/p/practice");
        WebElement text=driver.findElement(By.xpath("//td[contains(text(),'Python Programming Language')]//following-sibling::td"));
        System.out.println(text.getText());
        driver.close();
    }
}

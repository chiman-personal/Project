package Automation_Test;

public class NavigatePages {


}

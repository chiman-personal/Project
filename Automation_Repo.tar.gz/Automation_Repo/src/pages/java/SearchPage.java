import org.openqa.selenium.WebElement;

public class SearchPage {
    public static WebElement element=null;


}


import File.Payload;
import File.ResourcesBB;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import static io.restassured.RestAssured.given;

public class SimpleGetTest {
    //    @Test
//    public void GetWeatherDetails(){
//        RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city";
//        RequestSpecification httpRequest= given();
//
//        Response response = httpRequest.request(Method.GET, "/Hyderabad");
//        System.out.println("Response is ++++++++++++" + response);
//        String responseBody = response.getBody().asString();
//
//        System.out.println("Response Body is =>  " + responseBody);
//    }
    Properties properties = new Properties();
    ResourcesBB resource = new ResourcesBB();
    Payload payload = new Payload();

    @BeforeTest
    public void getData() throws IOException {

        FileInputStream file1 = new FileInputStream("/home/chiman/JavaPractice/Automation_Repo/src/RestAPI/File/env.properties");
        properties.load(file1);

    }

    @Test
    public void BBlogin() {
        RestAssured.baseURI = properties.getProperty("HOST");
        Response response = given().
                body(payload.logInPayload())
                .when().post(resource.logIn).then().extract().response();
        //System.out.println("Log In Response is "+ response.getBody());
        response.then().assertThat().statusCode(200).contentType(ContentType.JSON);
        String responseBody = response.getBody().asString();
        System.out.println(responseBody);
        JsonPath json = new JsonPath(responseBody);

        //Grab the session key from response
        System.out.println(json.get("result.session_key"));
        String session_key = json.getString("result.session_key");

        Response resp1 = given().body("{\"session_key\":\"" + session_key + "\",\"truck_num\":\"KA6967\"}").when().
                post(resource.unBlockTruck);
        resp1.then().statusCode(200);

        String truckres = resp1.getBody().asString();
        System.out.println(truckres);


    }
}

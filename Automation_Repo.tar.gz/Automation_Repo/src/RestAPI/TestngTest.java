import org.testng.annotations.*;
import org.testng.annotations.Test;

public class TestngTest {

    @BeforeTest
    public void beforetest(){
        System.out.println("Before Test");
    }

    @BeforeMethod
    public void beforeMethod(){
        System.out.println("Before Method");
    }

    @Test
    public void TestMethod1(){
        System.out.println("Test Method 1");
    }

    @Test
    public void TestMethod2(){
        System.out.println("Test Method 2");
    }

    @AfterMethod
    public void afterMethod(){
        System.out.println("After Method");
    }

    @AfterTest
    public void afterTest(){
        System.out.println("After Test");
    }
}

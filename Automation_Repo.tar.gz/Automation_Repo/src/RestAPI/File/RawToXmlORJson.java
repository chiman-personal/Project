package File;

import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class RawToXmlORJson {

    public XmlPath rawToXml(Response res){
        String response = res.asString();
        XmlPath xmlResponse=new XmlPath(response);

        return xmlResponse;

    }
    public JsonPath rawToJson(Response res){
        String response = res.asString();
        JsonPath jsonResponse = new JsonPath(response);

        return jsonResponse;

    }
}

package File;

public class ResourcesBB {
    public String logIn = "/android/login/";
    public String unBlockTruck = "/api/unblockTruck/";
}

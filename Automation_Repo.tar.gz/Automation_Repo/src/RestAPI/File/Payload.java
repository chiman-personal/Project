package File;

public class Payload {

    public String logInPayload(){
    String logInBody = "{\"username\":\"chiman.subudhi\",\n" +
        "\"password\":\"chiman.subudhi\"\n" +
                "}";
    return logInBody;
    }


}

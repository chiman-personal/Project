import File.Payload;
import File.RawToXmlORJson;
import File.ResourcesBB;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import io.restassured.response.Response;



public class OmsapiTest {

    Properties properties = new Properties();
    Payload payload = new Payload();
    ResourcesBB resourcesBB = new ResourcesBB();
    RawToXmlORJson rawToXmlORJson = new RawToXmlORJson();
    private String session_key;

    @BeforeTest
    public void getData() throws IOException {

        FileInputStream file = new FileInputStream("/home/chiman/JavaPractice/Automation_Repo/src/RestAPI/File/env.properties");
        properties.load(file);
    }

    @Test
    public void logIn(){
        RestAssured.baseURI = properties.getProperty("HOST");
        Response response= given().body(payload.logInPayload()).when().post(resourcesBB.logIn).then().assertThat().statusCode(200).and().contentType(ContentType.JSON).extract().response();
        System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
        JsonPath json=rawToXmlORJson.rawToJson(response);
        this.session_key = json.get("result.session_key");
        System.out.println(session_key);
    }
    @Test
    public void unblockTruck(){
        RestAssured.baseURI = properties.getProperty("HOST");

        given().body("{\"session_key\":\"" + session_key + "\",\"truck_num\":\"KA6967\"}").when().
                post(resourcesBB.unBlockTruck);

    }

}

package Section5;

public class FetchEachDigit {

    public static void main(String[] args) {
        int temp=154    ;int val1=0;
        while(temp>0){
            int r = temp%10;
            val1 =val1+( r*r*r);

            temp=temp/10;
        }System.out.println(val1);
    }
}

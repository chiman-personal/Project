package Section5;

public class ifElse {
    public static void main(String[] args) {
        int marks=70;

        if(marks<50){
            System.out.println("fail");
        }
        if(marks>=50 && marks<60){
            System.out.println("D grade");
        }
        if (marks>=60 && marks<=70){
            System.out.println("A grade");
        }else
            System.out.println("Got here ");
    }
}

package Section5;

public class Switch {
    public static void main(String[] args) {
        int number = 80;
        switch (number){
            case 10:
                System.out.println("10");
                break;
            case 20:
                System.out.println("20");
                break;
            case 30:
                System.out.println("30");
                break;
            default:
                System.out.println("Invalid ");
        }
    }
}

package Section5;

public class Primenumber {
    public static void Prime(int number) {
        int n = number / 2;
        int flag=0;

        if (number == 0 || number == 1) {
            System.out.println("This is not a prime number");
        } else {

            for (int i = 2; i < n; i++) {
                int z = number % i;
                if (z == 0) {
                    System.out.println("This is not a prime number");
                    flag=1;
                    break;
                }

            }if (flag==0){
                System.out.println("Prime number");
            }
        }
    }

    public static void main(String[] args) {
        Prime(31);
    }
}

package Section6;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Forloop {
    public static void main(String[] args) {
        for (int i=2;i<=8;i++){
            calculateInterest(10000,i);
        }
        double value = 500.52;
        BigDecimal bd = new BigDecimal(value);
        bd.setScale(2,BigDecimal.ROUND_CEILING);
        System.out.println(bd.setScale(2,BigDecimal.ROUND_CEILING));
        
        double d = 1;
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println(df.format(d));
        double x = value+d;

        System.out.println(x);
    }

    public static double calculateInterest(double amount,double interestRate){
        //System.out.println((amount*(interestRate/100)));
        //System.out.println(String.format("%.2f",(amount*(interestRate/100))));
        System.out.println(round((amount*(interestRate/100)),3));


        return (amount*(interestRate/100));
    }
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);

        bd = bd.setScale(places, BigDecimal.ROUND_HALF_UP);
        return bd.doubleValue();

    }
}

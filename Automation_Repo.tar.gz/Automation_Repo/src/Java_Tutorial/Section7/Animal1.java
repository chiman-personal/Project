package Section7;

public class Animal1 {
    public static void testClassMethod() {

        System.out.println("The static method in Animal");
    }
    public void testInstanceMethod() {

        System.out.println("The instance method in Animal");
    }
}

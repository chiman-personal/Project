package Section7;

class B{
    A4 obj;
    B(A4 obj){
        this.obj=obj;
    }
    void display(){
        System.out.println(obj.data);//using data member of A4 class
        System.out.println(obj);
    }
}

class A4{
    int data=10;
    A4(){
        B b=new B(this);
        b.display();
        System.out.println(this);
    }
    public static void main(String args[]){
        A4 a=new A4();
    }
}

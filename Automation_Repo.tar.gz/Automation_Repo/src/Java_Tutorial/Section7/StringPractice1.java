package Section7;

public class StringPractice1 {
    public static void main(String[] args) {
//        String s1="Java";
//        char ch[]={'S','t','r','i','n','g','s'};
//        String s2=new String(ch);
//
//        String s3=new String("Welcome");
//        System.out.println(s1);
//        System.out.println(s2);
//        System.out.println(s3);

        String s1="Sachin";
        String s2="SACHIN";
        String s3=new String("SACHIN");

        System.out.println(s1.equals(s3));//false
        System.out.println(s1.equalsIgnoreCase(s3));//true

        StringBuffer sb=new StringBuffer("Hello");
        //sb.replace(1,2,"Java");
        System.out.println(sb.charAt(5));
        System.out.println(sb);//prints HJavalo
    }
}

package Section7;

public class Main {
    public static void main(String[] args) {
        Car porsche = new Car();
        Car holden = new Car();
        porsche.setModel("Zsarrera");
        String model = porsche.getModel();

        System.out.println("Model of the car is "+model);

        System.out.println(porsche.hashCode());
        System.out.println(holden);

        BankAccounts bankAccounts = new BankAccounts();
        System.out.println(bankAccounts.getBalance());
        bankAccounts.depositFunds(500);
        System.out.println(bankAccounts.getBalance());
        bankAccounts.setBalance(1000);
        System.out.println(bankAccounts.getBalance());
        bankAccounts.depositFunds(800);
        System.out.println(bankAccounts.getBalance());
        bankAccounts.withdrawFunds(1700);
        bankAccounts.depositFunds(800);
        System.out.println(bankAccounts.getBalance());

    }
}

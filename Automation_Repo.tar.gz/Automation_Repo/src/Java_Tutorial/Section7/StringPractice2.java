package Section7;

import java.util.LinkedHashSet;
import java.util.Set;

public class StringPractice2 {
    public static void main(String[] args) {
        String input=new String("abbbbbbbbc");

        String result = "";
        for (int i = 0; i < input.length(); i++) {
            if(!result.contains(String.valueOf(input.charAt(i)))) {
                result += String.valueOf(input.charAt(i));
            }
        }
        System.out.println(result);


    }
}

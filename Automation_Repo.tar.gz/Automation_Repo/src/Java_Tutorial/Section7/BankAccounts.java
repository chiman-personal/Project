package Section7;

public class BankAccounts {

    private int accountNumber;
    private double balance;
    private String customerName;
    private String email;
    private long phoneNumber;

    public void depositFunds(double fund){
        this.balance = this.balance+fund;

    }
    public void withdrawFunds(double funds){
        if (this.balance - funds<0){
            System.out.println("Insufficient Balance");
        }else {
            this.balance = this.balance - funds;
            System.out.println("Current balance is "+this.balance);
        }

    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}

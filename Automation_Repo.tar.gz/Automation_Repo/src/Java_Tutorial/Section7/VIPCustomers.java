package Section7;

public class VIPCustomers {
    public String name;
    public int creditLimit;
    public String email;

    public VIPCustomers(){
        this("Chiman",5000,"chiman@gmail.com");
    }

    public VIPCustomers(String name, int creditLimit) {
        this(name,creditLimit,"unknown@email.com");
    }

    public VIPCustomers(String name, int creditLimit, String email) {
        this.name = name;
        this.creditLimit = creditLimit;
        this.email = email;
    }
}

package Exercise;

public class ExerciseMethodOverLoading {
    public static void main(String[] args) {
        double val = calFeetlandInchToCM(2,3);
        System.out.println(val);

        double calculation = calFeetlandInchToCM(13.25);
        System.out.println(calculation);
    }


    public static double calFeetlandInchToCM(double feet,double inch){
        if ((feet<=0) ||(inch<=0 && inch >12)){
            return -1;
        }
            double feetToCentemeter = (feet*12)*2.54;
            double inchTocM = inch*2.54;

        return feetToCentemeter+inchTocM;
    }

    public static double calFeetlandInchToCM(double inches){

        if (inches<=0){
            return -1;
        }

        double feet = (int) inches / 12;
        double remainingInches = inches % 12;
        System.out.println(inches + " inches is equal to " + feet + " feet and " + remainingInches + " inches");
        return calFeetlandInchToCM(feet,remainingInches);
    }
}

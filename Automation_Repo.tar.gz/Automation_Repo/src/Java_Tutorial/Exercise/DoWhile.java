package Exercise;

public class DoWhile {
    public static void main(String[] args) {
        int i=1;
        int count=0;
        while (i<6){
            if (oddEven(i)==true){
             count++;
             i++;
            }else

            i++;
        }
        System.out.println(count);

    }
    public static boolean oddEven(int num){
        if (num%2==0){
            System.out.println("Number " + num + " is a even number");
            return true;
        }else {
            System.out.println("Number " + num + " is a odd number");
            return false;}
    }
}

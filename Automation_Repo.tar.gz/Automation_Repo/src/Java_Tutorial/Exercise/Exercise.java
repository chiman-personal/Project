package Exercise;

public class Exercise {

    public static void main(String[] args) {

        double firstDouble = 20;
        double secondDouble = 80;
        double total = 25 * (firstDouble + secondDouble);
        System.out.println("Total after multiplication is "+ total);
        double modular = total % 40;
        System.out.println("Modular is "+modular);
        if (modular<=20){
            System.out.println("Total was over Limit");
        }
    }
}

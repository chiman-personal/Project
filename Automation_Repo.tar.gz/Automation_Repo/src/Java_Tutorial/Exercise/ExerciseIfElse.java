package Exercise;

public class ExerciseIfElse {
    public static void main(String[] args) {
        boolean gameOver = true;
        int score = 800;
        int levelComplete = 5;
        int bonus = 100;

        calculateScore();
        if (gameOver){
            score = 10000;
            levelComplete = 8;
            bonus=200;
            int finalSore = score+(levelComplete*bonus);
            System.out.println("Your second final score was: "+finalSore);
        }
    }

    public static void calculateScore(){
        boolean gameOver = true;
        int score = 800;
        int levelComplete = 5;
        int bonus = 100;

        if (gameOver){
            int finalSore = score+(levelComplete*bonus);
            System.out.println("Your final score was: "+finalSore);
        }
    }
}

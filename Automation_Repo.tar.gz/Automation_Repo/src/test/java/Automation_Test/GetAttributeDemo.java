package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetAttributeDemo {

    private WebDriver driver;
    private String baseUrl;
    private GenericMethods genObj;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        baseUrl="https://letskodeit.teachable.com/p/practice/?_ga=2.136793648.1484621676.1512885585-1760386564.1512885585";
        genObj=new GenericMethods(driver);
        driver.get(baseUrl);
    }

    @Test
    public void testGetText() throws Exception {
        driver.get(baseUrl);

        WebElement element = genObj.getElement("name","id");
        String attributeValue = element.getAttribute("type");

        System.out.println("Value of attribue is: " + attributeValue);
    }

    @After
    public void tearDown() throws Exception {
        Thread.sleep(2000);
        driver.quit();
    }
}



package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class SwitchHandlingTest {
    WebDriver driver;
    String baseUrl;
    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        baseUrl="http://letskodeit.teachable.com/pages/practice";
        driver.get(baseUrl);
    }

    @Test
    public void test(){

        String paretHandle=driver.getWindowHandle();
        System.out.println(paretHandle);

        WebElement openWindow= driver.findElement(By.id("openwindow"));
        openWindow.click();

        Set<String> handles=driver.getWindowHandles();

        for(String handle:handles){
            System.out.println(handle);
            if(!handle.equals(paretHandle)){
                driver.switchTo().window(handle);
                WebElement searchBox= driver.findElement(By.id("search-courses"));
                searchBox.sendKeys("Python");
                driver.close();
                break;
            }
        }
        driver.switchTo().window(paretHandle);
        WebElement opentab= driver.findElement(By.id("opentab"));
        opentab.click();


    }

    public static String getRandomString(int length) {
        StringBuilder sb = new StringBuilder();
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        for (int i = 0; i < length; i++) {
            int index = (int) (Math.random() * characters.length());
            sb.append(characters.charAt(index));
        }
        return sb.toString();
    }

    @After
    public void tearDown() throws Exception {
        String fileName = getRandomString(9);
        String directory = "//home//chiman//Desktop//";
        File sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        org.apache.commons.io.FileUtils.copyFile(sourceFile,new File(directory+fileName));
        Thread.sleep(3000);
        driver.quit();
    }

}
package Automation_Test;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class DropDownTest {
    WebDriver driver;
    String baseurl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        baseurl="https://letskodeit.teachable.com/p/practice/?_ga=2.136793648.1484621676.1512885585-1760386564.1512885585";
        driver.get(baseurl);
    }
    @Test
    public void test() throws InterruptedException {
        int count= 0;
        WebElement dropDown = driver.findElement(By.xpath("//*[@id=\"carselect\"]"));
        Select sel = new Select(dropDown);
        System.out.println(sel.isMultiple());
        List<WebElement> options=sel.getOptions();
        int size = options.size();
        System.out.println(size);
        System.out.println(dropDown.getText());


    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

}
package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class NavigatePagesTest {
    WebDriver driver;
    String baseurl ;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        baseurl= "https://letskodeit.teachable.com/";
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void test() throws InterruptedException {
        driver.get(baseurl);
        System.out.println("Title of webpage is: "+driver.getTitle());
        System.out.println("Current URL is: "+ driver.getCurrentUrl());

        String urlToNavigate = "https://sso.teachable.com/secure/42299/users/sign_in?clean_login=true&reset_purchase_session=1";
        driver.navigate().to(urlToNavigate);
        Thread.sleep(3000);
        driver.navigate().back();

        Thread.sleep(2000);
        driver.navigate().forward();

        Thread.sleep(1000);
        driver.navigate().refresh();



    }
    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

}
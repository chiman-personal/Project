package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.peer.SystemTrayPeer;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class enterKeysTest {
    WebDriver driver;
    String baseurl ;


    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        baseurl= "https://letskodeit.teachable.com/";
        driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void test() throws InterruptedException {
        driver.get(baseurl);
        driver.findElement(By.partialLinkText("Login")).click();
        driver.findElement(By.id("user_email")).sendKeys("test@email.com");
        driver.findElement(By.id("user_password")).sendKeys("test");
        driver.findElement(By.xpath("//*[@id=\"new_user\"]/div[3]/input")).click();
        Thread.sleep(2000);
    }

    @After
    public void tearDown() throws Exception {
        driver.close();
    }

}
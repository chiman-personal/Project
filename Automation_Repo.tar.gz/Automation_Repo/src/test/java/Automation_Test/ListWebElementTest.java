package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

import static org.junit.Assert.*;

public class ListWebElementTest {
    WebDriver driver;
    String baseURL;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        baseURL="https://letskodeit.teachable.com/p/practice/?_ga=2.136793648.1484621676.1512885585-1760386564.1512885585";
        driver.get(baseURL);
    }

    @Test
    public void test() throws InterruptedException {
        boolean isChecked = false;
        List<WebElement> radioButtons = driver.findElements(By.xpath("//input[contains(@type,'radio') and contains(@name,'cars')]"));
        int size = radioButtons.size();
        System.out.println("Number of radio buttons are: "+ size);
        for (int i=0;i<size;i++){
            isChecked=radioButtons.get(i).isSelected();
            if (!isChecked) {
                radioButtons.get(i).click();
                System.out.println(radioButtons.get(i).getText());
                Thread.sleep(2000);

            }
        }

    }
    //Why System.out.println(radioButtons.get(i).getText()); is not giving me the text?
    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

}
package Automation_Test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import javax.swing.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

public class Blackbuck_AutomationTest {
    WebDriver driver;
    String baseUrl;
    JavascriptExecutor js;
    @Before
    public void setUp() throws Exception {;
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        js=(JavascriptExecutor)driver;
        baseUrl="https://sitemployees.blackbuck.com/";
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(baseUrl);
        driver.findElement(By.id("username")).sendKeys("chiman.subudhi");
        driver.findElement(By.id("password")).sendKeys("chiman.subudhi");
        driver.findElement(By.id("login-btn")).click();
    }

    public static List<WebElement> clickableLinks(WebDriver driver){
        List<WebElement> linksToClick = new ArrayList<WebElement>();
        List<WebElement> elements=driver.findElements(By.tagName("a"));
        elements.addAll(driver.findElements(By.tagName("img")));

        for (WebElement ea : elements){
            try{
                if (ea.getAttribute("href")!=null){
                    linksToClick.add(ea);
                }
            }

        catch (StaleElementReferenceException e){
            System.out.println(e.getMessage());
        }



    }return linksToClick;
    }

    public static String linkStatus(URL url){
        try {
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.connect();
            String responseMessage=http.getResponseMessage();
            http.disconnect();
            return responseMessage;
        }
        catch (Exception e) {
            return e.getMessage();
        }
    }

//    @Test
//    public void testMouseHover(){
//        WebElement menuOrder = driver.findElement(By.id("menu_orders"));
//        Actions actions = new Actions(driver);
//        actions.moveToElement(menuOrder).perform();
//        WebElement viewOrderOption = driver.findElement(By.partialLinkText("View Orders"));
//        actions.moveToElement(viewOrderOption).click().perform();
//
//    }

    @Test
    public void testFindLinks(){
        WebElement menuOrder = driver.findElement(By.id("menu_orders"));
        Actions actions = new Actions(driver);
        actions.moveToElement(menuOrder).perform();
        WebElement viewOrderOption = driver.findElement(By.partialLinkText("View Orders"));
        actions.moveToElement(viewOrderOption).click().perform();
        List<WebElement> linksList = clickableLinks(driver);
        for (WebElement link : linksList) {


            try {
                String href = link.getAttribute("href");
                String name = link.getText();
                System.out.println("URL " + href + " returned " + linkStatus(new URL(href)) + name );
            }


            catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        
    }


    @After
    public void tearDown() throws Exception {
        Thread.sleep(6000);
        driver.quit();
    }

}
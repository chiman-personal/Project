package Automation_Test;

import com.sun.jna.platform.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CalendarSelection {

    private WebDriver driver;
    private String baseUrl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        baseUrl = "https://www.expedia.co.in/?adobe_mc=MCMID%3D12111814162450863154265391807244442247";

        // Maximize the browser's window
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @Test
    public void test1() throws Exception {
        driver.get(baseUrl);
        // Click flights tab
        driver.findElement(By.id("tab-flight-tab")).click();
        // Find departing field
        WebElement departingField = driver.findElement(By.id("flight-departing"));
        // Click departing field
        departingField.click();
        Thread.sleep(3000);
        WebElement calmonth=driver.findElement(By.xpath("//div[@class='datepicker-cal-month'][position()=1]"));
        List<WebElement> allValidDates = calmonth.findElements(By.tagName("td"));

        Thread.sleep(3000);

        for (WebElement date : allValidDates) {
            if (date.getText().equals("30")) {
                date.click();
                break;
            }
        }
        // Find the date to be selected
//        WebElement dateToSelect = driver.findElement(By.xpath("//*[@id=\"flight-departing-wrapper\"]/div/div/div[2]/table/tbody/tr[5]/td[7]/button"));
//        // Click the date
//        dateToSelect.click();
    }

    public static String getRandomString(int length) {
        StringBuilder sb = new StringBuilder();
        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        for (int i = 0; i < length; i++) {
            int index = (int) (Math.random() * characters.length());
            System.out.println("index is "+index);
            System.out.println("Random num is"+Math.random());
            sb.append(characters.charAt(index));
        }
        return sb.toString();
    }

    @After
    public void tearDown() throws Exception {
        String fileName = getRandomString(10);
        String directory = "//home//chiman//Desktop//";
        File sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        org.apache.commons.io.FileUtils.copyFile(sourceFile,new File(directory+fileName));
        Thread.sleep(3000);
        driver.quit();
    }
}

package Automation_Test;

import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class FileUploadTest {

    WebDriver driver;
    String baseurl;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver","/home/chiman/Documents/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        baseurl="http://demoqa.com/registration/";
        driver.get(baseurl);
//        driver.findElement(By.id("username")).sendKeys("chiman.subudhi");
//        driver.findElement(By.id("password")).sendKeys("chiman.subudhi");
//        driver.findElement(By.id("login-btn")).click();
//        driver.get(baseurl);
        driver.findElement(By.id("profile_pic_10")).sendKeys("/home/chiman/Documents/218801.png");

    }
    @org.junit.Test
    public void test() throws InterruptedException {



    }
}

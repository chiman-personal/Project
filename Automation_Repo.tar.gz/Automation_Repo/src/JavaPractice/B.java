public class B extends A{
    B(){

        System.out.println("Class B default const");
    }

    B(int a){

        System.out.println("Class B const");
    }

    public static void main(String[] args) {
        B b1=new B();

    }

}   
public class Demo {

    public static void main(String[] args) {
        boolean isCar = false;
        if (isCar==false){
            System.out.println(isCar);
        }
        boolean wasCar = isCar? false:true;
        if (wasCar){
            System.out.println("was Car "+ wasCar);
        }
    }
}

public class A {
    A(){
        System.out.println("Class A constructor");
    }
}


